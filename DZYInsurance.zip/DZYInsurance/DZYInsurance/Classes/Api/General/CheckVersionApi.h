//
//  CheckVersionApi.h
//  DZYInsurance
//
//  Created by 周永超 on 16/7/11.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import "YTKRequest.h"

@interface CheckVersionApi : YTKRequest

@end
