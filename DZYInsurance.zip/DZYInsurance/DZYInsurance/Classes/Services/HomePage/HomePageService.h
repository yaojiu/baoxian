//
//  HomePageService.h
//  DZYInsurance
//
//  Created by zhouyongchao on 16/1/25.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomePageService : NSObject

- (void)achieveBigCategory;

@end
