//
//  HomePageController.h
//  DZYInsurance
//
//  Created by zhouyongchao on 16/1/22.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import "PageRefreshController.h"

@interface HomePageController : PageRefreshController

@end
