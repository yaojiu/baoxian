//
//  LoginController.h
//  DZYInsurance
//
//  Created by Dao on 2017/8/2.
//  Copyright © 2017年 zhouyongchao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YxLoginController : UIViewController

@end
