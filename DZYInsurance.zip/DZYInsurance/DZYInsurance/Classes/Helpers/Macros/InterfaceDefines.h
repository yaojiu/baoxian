//
//  InterfaceDefines.h
//  DZYInsurance
//
//  Created by 周永超 on 2017/7/21.
//  Copyright © 2017年 zhouyongchao. All rights reserved.
//

#ifndef InterfaceDefines_h
#define InterfaceDefines_h

#define CUSTOM_NAV_HEIGHT                       64//导航栏高度
#define NAVIGATION_BAR_COLOR                    Color_RGB(44, 70, 105, 1)

#endif /* InterfaceDefines_h */
