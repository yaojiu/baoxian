//
//  VersionDTO.m
//  DZYInsurance
//
//  Created by 周永超 on 16/7/11.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import "VersionDTO.h"

@implementation VersionData

@end

@implementation VersionDTO

@end
