//
//  BaseDTO.h
//  DZYInsurance
//
//  Created by 周永超 on 16/6/21.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseDTO : NSObject

@property (nonatomic, copy) NSString *result;
@property (nonatomic, copy) NSString *message;

@end
