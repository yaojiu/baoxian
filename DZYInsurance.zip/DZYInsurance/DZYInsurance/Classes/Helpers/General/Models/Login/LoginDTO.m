//
//  LoginDTO.m
//  DZYInsurance
//
//  Created by 周永超 on 16/6/21.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import "LoginDTO.h"

@implementation LoginData

@end

@implementation LoginDTO

@end
