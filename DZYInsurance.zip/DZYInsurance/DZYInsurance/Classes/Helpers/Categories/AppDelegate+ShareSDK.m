//
//  AppDelegate+ShareSDK.m
//  DZYInsurance
//
//  Created by zhouyongchao on 16/1/25.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import "AppDelegate+ShareSDK.h"

@implementation AppDelegate (ShareSDK)

- (void)integrateShareSDKWithApplication:(UIApplication *)application launchOptions:(NSDictionary *)options {
    
}

@end
