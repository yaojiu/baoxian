//
//  AppDelegate+UMeng.h
//  DZYInsurance
//
//  Created by zhouyongchao on 16/2/15.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (UMeng)

- (void)integrateUMengWithApplication:(UIApplication *)application options:(NSDictionary *)launchOptions;

@end
