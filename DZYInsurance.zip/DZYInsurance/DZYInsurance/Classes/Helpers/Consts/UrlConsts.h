//
//  UrlConsts.h
//  DZYInsurance
//
//  Created by zhouyongchao on 16/1/25.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import <UIKit/UIKit.h>
UIKIT_EXTERN NSString *const BASEURL;

//登录url
UIKIT_EXTERN NSString *const LoginUrl;
//检查版本更新url
UIKIT_EXTERN NSString *const CheckVersionUpdateUrl;
//itunes connect app url
UIKIT_EXTERN NSString *const ITunesAppUrl;

