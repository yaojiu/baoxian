//
//  UrlConsts.m
//  DZYInsurance
//
//  Created by zhouyongchao on 16/1/25.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import <UIKit/UIKit.h>
//NSString *const BASEURL = @"http://shadowpowder.exxonmovie.com";
NSString *const BASEURL = @"http://123.57.30.207:50/order/api.php/home/api/";

NSString *const LoginUrl = @"login";
NSString *const CheckVersionUpdateUrl = @"";
NSString *const ITunesAppUrl = @"";
