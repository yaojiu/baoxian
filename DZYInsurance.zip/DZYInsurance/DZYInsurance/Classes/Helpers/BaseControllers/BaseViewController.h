//
//  BaseViewController.h
//  DZYInsurance
//
//  Created by zhouyongchao on 16/1/25.
//  Copyright © 2016年 zhouyongchao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

- (void)showTextMessage:(NSString *)message afterDelay:(NSTimeInterval)delay;

@end
